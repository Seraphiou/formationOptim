/*
 * Copyright OXIANE, 98 avenue du Gal Leclerc, 92100 Boulogne. Tous droits réserves.
 * Ce produit ou document est protege par un copyright et distribue avec des licences
 * qui en restreignent l'utilisation, la copie, la distribution, et la decompilation.
 * Ce produit peut etre reproduit par les stagiaires des formations dispensees par
 * OXIANE.
 * OXIANE, le logo OXIANE sont des marques de fabrique ou des marques deposees, ou
 * marques de service, de OXIANE en France et dans d'autres pays.
 * CETTE PUBLICATION EST FOURNIE "EN L'ETAT" ET AUCUNE GARANTIE, EXPRESSE OU IMPLICITE,
 * N'EST ACCORDEE, Y COMPRIS DES GARANTIES CONCERNANT LA VALEUR MARCHANDE, L'APTITUDE
 * DE LA PUBLICATION A REPONDRE A UNE UTILISATION PARTICULIERE, OU LE FAIT QU'ELLE NE
 * SOIT PAS CONTREFAISANTE DE PRODUIT DE TIERS. CE DENI DE GARANTIE NE S'APPLIQUERAIT
 * PAS, DANS LA MESURE OU IL SERAIT TENU JURIDIQUEMENT NUL ET NON AVENU.
 */
package com.oxiane.formation.lists;

import java.lang.reflect.Constructor;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 *
 * @author cmarchand
 */
public class App {
    public static void main(String[] args) {
        run("java.util.ArrayList");
        System.out.println("\n\n");
        run("java.util.LinkedList");
    }
    public static void run(String className) {
        List<Object> lists[] = new List[6];
        for(int i=0; i< 6 ; i++) {
            lists[i] = constructList(className);
        }
        System.out.println("Working on "+lists[0].getClass().getName());
        fillList(lists);
        readFromLists(lists);
        iterateFromLists(lists);
        // on vide
        for(int i=0; i<lists.length;i++) {
            lists[i].clear();
        }
        gc();
    }
    
    private static List<Object> constructList(String className) {
        try {
            Class clazz = Class.forName(className);
            Class[] types = new Class[0];
            Constructor<List> c = clazz.getConstructor(types);
            return c.newInstance((Object[])null);
        } catch(Exception ex) {
            ex.printStackTrace(System.err);
        }
        return null;
    }
    
    private static void fillList(List<Object> lists[]) {
        Random r = new Random();
        // on instancie 5 fois des Value pour éliminer le temps de chargement de la classe
        for( int i=0; i<5 ; i++) {
            Value v = new Value(r.nextLong());
            long p = v.getLong() / 2;
        }
        long p0 = 0;
        for(int i=0 ; i<10 ; i++) {
            Value v = new Value(r.nextLong());
            long start = getDate();
            lists[0].add(v);
            p0 += (getDate() - start);
        }
        long p1 = 0;
        for(int i=0 ; i<100 ; i++) {
            Value v = new Value(r.nextLong());
            long start = getDate();
            lists[1].add(v);
            p1 += (getDate() - start);
        }
        long p2 = 0;
        for(int i=0 ; i<1000 ; i++) {
            Value v = new Value(r.nextLong());
            long start = getDate();
            lists[2].add(v);
            p2 += (getDate() - start);
        }
        long p3 = 0;
        for(int i=0 ; i<10000 ; i++) {
            Value v = new Value(r.nextLong());
            long start = getDate();
            lists[3].add(v);
            p3 += (getDate() - start);
        }
        long p4 = 0;
        for(int i=0 ; i<100000 ; i++) {
            Value v = new Value(r.nextLong());
            long start = getDate();
            lists[4].add(v);
            p4 += (getDate() - start);
        }
        long p5 = 0;
        for(int i=0 ; i<1000000 ; i++) {
            Value v = new Value(r.nextLong());
            long start = getDate();
            lists[5].add(v);
            p5 += (getDate() - start);
        }
        System.out.println("adding      10 : "+p0+" ns, "+p0/10+" ns per insert");
        System.out.println("adding     100 : "+p1+" ns, "+p1/100+" ns per insert");
        System.out.println("adding    1000 : "+p2+" ns, "+p2/1000+" ns per insert");
        System.out.println("adding   10000 : "+p3+" ns, "+p3/10000+" ns per insert");
        System.out.println("adding  100000 : "+p4+" ns, "+p4/100000+" ns per insert");
        System.out.println("adding 1000000 : "+p5+" ns, "+p5/1000000+" ns per insert");
    }
    
    private static void readFromLists(final List<Object> lists[]) {
        for(int i=0; i< lists.length ; i++) {
            readFromList(lists[i]);
        }
    }
    private static void readFromList(final List<Object> list) {
        int size = list.size();
        long count = 0;
        Random r = new Random();
        int limit = size / 5;
        double avg = 0;
        for ( int i= 0 ; i< limit ; i++) {
            int rank = (int)(r.nextDouble() * size);
            long start = getDate();
            Value v = (Value)list.get(rank);
            avg += v.getLong();
            count += (getDate()-start);
        }
        avg = avg / limit;
        System.out.println("get: "+count+" ns, "+(count / limit)+"ns per read, for "+limit+" reads in "+size+" length list. Avg is "+avg);
    }
    
    private static void iterateFromLists(List<Object>[] lists) {
        for(int i=0; i<lists.length; i++) {
            iterateFromList(lists[i]);
        }
    }
    
    private static void iterateFromList(List<Object> list) {
        int size = list.size();
        long count = getDate();
        double avg = 0;
        Iterator<Object> it = list.iterator();
        count = (getDate() - count);
        while(it.hasNext()) {
            long start = getDate();
            Value v = (Value)it.next();
            count += (getDate() - start);
            avg += v.getLong();
        }
        avg = avg / size;
        System.out.println("iterate: "+count+"ns ("+(count/size)+"ns per element) over "+size+" elements. Avg is "+avg);
    }
    
    private static class Value {
        private long l;
        public Value(final long l) {
            super();
            this.l=l;
        }
        public long getLong() { return l; }
    }
    
    private static long getDate() { return System.nanoTime(); }
    
    private static void gc() {
        try {
            System.gc();
            Thread.sleep(100);
            System.runFinalization();
            Thread.sleep(100);
            System.gc();
            Thread.sleep(100);
            System.runFinalization();
            Thread.sleep(100);
        } catch (Exception e) {
            e.printStackTrace(System.err);
        }
    }
}
