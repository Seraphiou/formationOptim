/*
 * Copyright OXIANE, 98 avenue du Gal Leclerc, 92100 Boulogne. Tous droits réserves.
 * Ce produit ou document est protege par un copyright et distribue avec des licences
 * qui en restreignent l'utilisation, la copie, la distribution, et la decompilation.
 * Ce produit peut etre reproduit par les stagiaires des formations dispensees par
 * OXIANE.
 * OXIANE, le logo OXIANE sont des marques de fabrique ou des marques deposees, ou
 * marques de service, de OXIANE en France et dans d'autres pays.
 * CETTE PUBLICATION EST FOURNIE "EN L'ETAT" ET AUCUNE GARANTIE, EXPRESSE OU IMPLICITE,
 * N'EST ACCORDEE, Y COMPRIS DES GARANTIES CONCERNANT LA VALEUR MARCHANDE, L'APTITUDE
 * DE LA PUBLICATION A REPONDRE A UNE UTILISATION PARTICULIERE, OU LE FAIT QU'ELLE NE
 * SOIT PAS CONTREFAISANTE DE PRODUIT DE TIERS. CE DENI DE GARANTIE NE S'APPLIQUERAIT
 * PAS, DANS LA MESURE OU IL SERAIT TENU JURIDIQUEMENT NUL ET NON AVENU.
 */ 
package com.oxiane.formation.requestexecutor;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author cmarchand
 */
public class Triangle {
    private static final double LIMIT = 0.01;
    private double c1, c2, c3;
    
    public Triangle() {
        super();
    }
    public Triangle(double c1, double c2, double c3) {
        this();
        __init(c1, c2, c3);
    }
    public Triangle(ResultSet rs) throws SQLException {
        this();
        init(rs);
    }
    
    public void init(ResultSet rs) throws SQLException {
        __init(rs.getDouble(1), rs.getDouble(2), rs.getDouble(3));
    }
    private void __init(double c1, double c2, double c3) {
        this.c1=c1;
        this.c2=c2;
        this.c3=c3;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Triangle \t");
        if(c1==c2 && c1==c3) {
            sb.append("isocèle");
        } else {
            if(c1==c2 || c2==c3 || c3==c1) {
                sb.append("équilatéral\t");
            }
            double sq1 = c1*c1;
            double sq2 = c2*c2;
            double sq3 = c3*c3;
            if(Math.abs(sq1 - sq2 - sq3) < LIMIT || 
                    Math.abs(sq2 - sq1 - sq3) < LIMIT || 
                    Math.abs(sq3 - sq1 - sq2) < LIMIT ) {
                sb.append("rectangle");
            }
        }
        return sb.toString();
    }
    
}
