/*
 * Copyright OXIANE, 98 avenue du Gal Leclerc, 92100 Boulogne. Tous droits réserves.
 * Ce produit ou document est protege par un copyright et distribue avec des licences
 * qui en restreignent l'utilisation, la copie, la distribution, et la decompilation.
 * Ce produit peut etre reproduit par les stagiaires des formations dispensees par
 * OXIANE.
 * OXIANE, le logo OXIANE sont des marques de fabrique ou des marques deposees, ou
 * marques de service, de OXIANE en France et dans d'autres pays.
 * CETTE PUBLICATION EST FOURNIE "EN L'ETAT" ET AUCUNE GARANTIE, EXPRESSE OU IMPLICITE,
 * N'EST ACCORDEE, Y COMPRIS DES GARANTIES CONCERNANT LA VALEUR MARCHANDE, L'APTITUDE
 * DE LA PUBLICATION A REPONDRE A UNE UTILISATION PARTICULIERE, OU LE FAIT QU'ELLE NE
 * SOIT PAS CONTREFAISANTE DE PRODUIT DE TIERS. CE DENI DE GARANTIE NE S'APPLIQUERAIT
 * PAS, DANS LA MESURE OU IL SERAIT TENU JURIDIQUEMENT NUL ET NON AVENU.
 */ 
package com.oxiane.formation.requestexecutor;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Hello world!
 *
 */
public class App {
    private static final int SIZE = 50;

    public static void main(String[] args) {
        System.out.println("Starting hSqlDB");
        Connection con = null;
        try {
            Class.forName("org.hsqldb.jdbc.JDBCDriver");
            con = DriverManager.getConnection("jdbc:hsqldb:mem:mymemdb;shutdown=true", "SA", "");
            System.out.println("Database started, initializing data");
            __initDatabase(con);
            System.out.println("Data inserted, starting process");

            // pour la sortie
            PrintWriter pw = new PrintWriter(new NullOutputStream());
            long durations[] = new long[SIZE];
            for(int i=0; i<SIZE; i++) {
                ResultSet rs = con.createStatement().executeQuery("SELECT c1, c2, c3 FROM triangle");
                long start = System.currentTimeMillis();
                rs.next();
                Triangle t = new Triangle(rs);
                pw.println(t.toString());
                while(rs.next()) {
//                    Triangle t = new Triangle(rs);
                    t.init(rs);
                    pw.println(t.toString());
                }

                rs.close();
                long end = System.currentTimeMillis();
                durations[i] = end-start;
            }
            Arrays.sort(durations);
            long min = 999999999;
            long max = 0;
            long avg = 0;
            // exclusion des peux plus petites et des deux plus grandes valeurs,
            // pour supprimer les extremes
            for(int i=2;i<(durations.length-2);i++) {
                min = Math.min(min, durations[i]);
                max = Math.max(max, durations[i]);
                avg+= durations[i];
            }
            pw.flush(); pw.close();
            System.out.println("Fetch duration : min="+min+" avg="+(avg/(durations.length-4))+" max="+max);
        } catch(Exception ex) {
            ex.printStackTrace(System.err);
        } finally {
            if(con!=null) {
                try { con.close(); } catch(Throwable t) {}
            }
        }
    }
    
    private static void __initDatabase(final Connection con) throws Exception {
        Statement st = con.createStatement();
        st.executeUpdate("CREATE TABLE triangle (c1 NUMERIC NOT NULL, c2 NUMERIC NOT NULL, c3 NUMERIC NOT NULL)");
        PreparedStatement ps = con.prepareStatement("INSERT INTO triangle (c1, c2, c3) VALUES (?,?,?)");
        loadXml(ps);
        con.commit();
        ResultSet rs = st.executeQuery("SELECT count(*) FROM triangle");
        rs.next();
        System.out.println(rs.getInt(1)+" rows inserted");
        rs.close();
        st.close();
    }
    
    private static void loadXml(PreparedStatement ps) throws Exception {
        long start = System.currentTimeMillis();
        SAXParserFactory factory = SAXParserFactory.newInstance();
        SAXParser parser = factory.newSAXParser();
        InputStream is = App.class.getResourceAsStream("/com/oxiane/formation/requestexecutor/triangles.xml");
        parser.parse(is, (DefaultHandler)new TriangleHandler(ps));
        is.close();
        long stop = System.currentTimeMillis();
        System.out.println("Insert take "+(stop-start)+"ms");
    }
    
    private static class TriangleHandler extends DefaultHandler {
        private PreparedStatement ps = null;
        public TriangleHandler(final PreparedStatement ps) {
            super();
            this.ps=ps;
        }
        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            if("triangle".equals(qName)) {
                try {
                    ps.setBigDecimal(1, BigDecimal.valueOf(Double.valueOf(attributes.getValue("c1"))));
                    ps.setBigDecimal(2, BigDecimal.valueOf(Double.valueOf(attributes.getValue("c2"))));
                    ps.setBigDecimal(3, BigDecimal.valueOf(Double.valueOf(attributes.getValue("c3"))));
                } catch(SQLException sqlEx) {
                    throw new SAXException(sqlEx);
                }
            }
        }
        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            if("triangle".equals(qName)) {
                try {
                    ps.executeUpdate();
                } catch(SQLException sqlEx) {
                    throw new SAXException(sqlEx);
                }
            }
        }
        
    }
    private static class NullOutputStream extends OutputStream {
        private long count;
        @Override
        public void write(int b) throws IOException {
            count++;
        }

        @Override
        public void close() throws IOException {
            super.close();
            System.out.println("written "+count+" bytes");
        }
        
    }
}
