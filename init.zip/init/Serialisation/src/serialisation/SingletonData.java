/*
 * Copyright OXIANE, 98 avenue du Gal Leclerc, 92100 Boulogne. Tous droits réserves.
 * Ce produit ou document est protege par un copyright et distribue avec des licences
 * qui en restreignent l'utilisation, la copie, la distribution, et la decompilation.
 * Ce produit peut etre reproduit par les stagiaires des formations dispensees par
 * OXIANE.
 * OXIANE, le logo OXIANE sont des marques de fabrique ou des marques deposees, ou
 * marques de service, de OXIANE en France et dans d'autres pays.
 * CETTE PUBLICATION EST FOURNIE "EN L'ETAT" ET AUCUNE GARANTIE, EXPRESSE OU IMPLICITE,
 * N'EST ACCORDEE, Y COMPRIS DES GARANTIES CONCERNANT LA VALEUR MARCHANDE, L'APTITUDE
 * DE LA PUBLICATION A REPONDRE A UNE UTILISATION PARTICULIERE, OU LE FAIT QU'ELLE NE
 * SOIT PAS CONTREFAISANTE DE PRODUIT DE TIERS. CE DENI DE GARANTIE NE S'APPLIQUERAIT
 * PAS, DANS LA MESURE OU IL SERAIT TENU JURIDIQUEMENT NUL ET NON AVENU.
 */
package serialisation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author cmarchand
 */
public class SingletonData {
    private static final SingletonData __INSTANCE = new SingletonData();
    private Map<String,Pays> pays;
    private Map<String,Adresse> adresses;
    
    public static SingletonData getInstance() {
        return __INSTANCE;
    }
    private SingletonData() {
        super();
        pays=new HashMap<>();
        adresses=new HashMap<>();
    }
    
    public Pays getPays(final String code) { return pays.get(code); }
    public Adresse getAdresse(final String codeAdresse) { return adresses.get(codeAdresse); }
    
    public String addPays(final Pays p) {
        pays.put(p.getCode(),p);
        return p.getCode();
    }
    public String addAdresse(final Adresse adr) {
        adresses.put(adr.computeCodeAdresse(),adr);
        return adr.getCodeAdresse();
    }
    
    void init() {
        getInstance().addPays(new Pays("FRA","France"));
        getInstance().addPays(new Pays("GBR","Grande Bretagne"));
        getInstance().addPays(new Pays("USA", "Etats-Unis"));
        getInstance().addPays(new Pays("DEU", "Allemagne"));
        getInstance().addAdresse(new Adresse(null, "50 avenue du Général de Gaulle", null, "94300", "Vincennes", "FRA"));
        getInstance().addAdresse(new Adresse(null, "98 avenue du Général Leclerc", null, "92100", "Boulogne", "FRA"));
    }
}
