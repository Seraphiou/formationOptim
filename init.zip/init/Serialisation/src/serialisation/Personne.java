/*
 * Copyright OXIANE, 98 avenue du Gal Leclerc, 92100 Boulogne. Tous droits réserves.
 * Ce produit ou document est protege par un copyright et distribue avec des licences
 * qui en restreignent l'utilisation, la copie, la distribution, et la decompilation.
 * Ce produit peut etre reproduit par les stagiaires des formations dispensees par
 * OXIANE.
 * OXIANE, le logo OXIANE sont des marques de fabrique ou des marques deposees, ou
 * marques de service, de OXIANE en France et dans d'autres pays.
 * CETTE PUBLICATION EST FOURNIE "EN L'ETAT" ET AUCUNE GARANTIE, EXPRESSE OU IMPLICITE,
 * N'EST ACCORDEE, Y COMPRIS DES GARANTIES CONCERNANT LA VALEUR MARCHANDE, L'APTITUDE
 * DE LA PUBLICATION A REPONDRE A UNE UTILISATION PARTICULIERE, OU LE FAIT QU'ELLE NE
 * SOIT PAS CONTREFAISANTE DE PRODUIT DE TIERS. CE DENI DE GARANTIE NE S'APPLIQUERAIT
 * PAS, DANS LA MESURE OU IL SERAIT TENU JURIDIQUEMENT NUL ET NON AVENU.
 */
package serialisation;

import java.io.IOException;
import java.io.Serializable;

/**
 * Une entreprise.
 * @author cmarchand
 */
public class Personne implements Serializable {
    private String prenom, nom, civilite;
    private SEXE sexe;
    private Adresse adresse;
    private String codeAdresse;
    
    public Personne() {
        super();
    }
    Personne(final String prenom, final String nom, final String civilite, final SEXE sexe, final String codeAdresse) {
        this();
        this.prenom=prenom;
        this.nom=nom;
        this.civilite=civilite;
        this.sexe=sexe;
        this.codeAdresse=codeAdresse;
        adresse = SingletonData.getInstance().getAdresse(codeAdresse);
    }

    public enum SEXE {
        MASCULIN,FEMININ;
    }

    public Adresse getAdresse() {
        return adresse;
    }

    public void setAdresse(Adresse adresse) {
        this.adresse = adresse;
    }

    public String getCivilite() {
        return civilite;
    }

    public void setCivilite(String civilite) {
        this.civilite = civilite;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public SEXE getSexe() {
        return sexe;
    }

    public void setSexe(SEXE sexe) {
        this.sexe = sexe;
    }

}
