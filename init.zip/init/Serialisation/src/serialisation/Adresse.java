/*
 * Copyright OXIANE, 98 avenue du Gal Leclerc, 92100 Boulogne. Tous droits réserves.
 * Ce produit ou document est protege par un copyright et distribue avec des licences
 * qui en restreignent l'utilisation, la copie, la distribution, et la decompilation.
 * Ce produit peut etre reproduit par les stagiaires des formations dispensees par
 * OXIANE.
 * OXIANE, le logo OXIANE sont des marques de fabrique ou des marques deposees, ou
 * marques de service, de OXIANE en France et dans d'autres pays.
 * CETTE PUBLICATION EST FOURNIE "EN L'ETAT" ET AUCUNE GARANTIE, EXPRESSE OU IMPLICITE,
 * N'EST ACCORDEE, Y COMPRIS DES GARANTIES CONCERNANT LA VALEUR MARCHANDE, L'APTITUDE
 * DE LA PUBLICATION A REPONDRE A UNE UTILISATION PARTICULIERE, OU LE FAIT QU'ELLE NE
 * SOIT PAS CONTREFAISANTE DE PRODUIT DE TIERS. CE DENI DE GARANTIE NE S'APPLIQUERAIT
 * PAS, DANS LA MESURE OU IL SERAIT TENU JURIDIQUEMENT NUL ET NON AVENU.
 */
package serialisation;

import java.io.Serializable;
import java.nio.charset.Charset;
import jonelo.jacksum.algorithm.AbstractChecksum;
import jonelo.jacksum.algorithm.MD;

/**
 * Représente une adresse.
 * @author cmarchand
 */
public class Adresse implements Serializable {
    private String adr1, adr2, adr3, cp, ville, codePays;
    private Pays pays;
    private String codeAdresse;
    
    public Adresse() {
        super();
    }
    Adresse(final String adr1,
            final String adr2,
            final String adr3,
            final String cp,
            final String ville,
            final String codePays) {
        this();
        this.adr1=adr1;
        this.adr2=adr2;
        this.adr3=adr3;
        this.cp=cp;
        this.ville=ville;
        this.codePays=codePays;
        pays=SingletonData.getInstance().getPays(codePays);
    }

    public String getAdr1() {
        return adr1;
    }

    public void setAdr1(String adr1) {
        this.adr1 = adr1;
    }

    public String getAdr2() {
        return adr2;
    }

    public void setAdr2(String adr2) {
        this.adr2 = adr2;
    }

    public String getAdr3() {
        return adr3;
    }

    public void setAdr3(String adr3) {
        this.adr3 = adr3;
    }

    public String getCodePays() {
        return codePays;
    }

    public void setCodePays(String codePays) {
        this.codePays = codePays;
    }

    public String getCp() {
        return cp;
    }

    public void setCp(String cp) {
        this.cp = cp;
    }

    public Pays getPays() {
        return pays;
    }

    public void setPays(Pays pays) {
        this.pays = pays;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public String getCodeAdresse() { return codeAdresse; }
    public void setCodeAdresse(String codeAdresse) {
        this.codeAdresse = codeAdresse;
    }

    public String computeCodeAdresse() {
        Charset cs = Charset.forName("UTF-16");
        try {
            AbstractChecksum ac = new MD("SHA1");
            if(adr1!=null)
                ac.update(adr1.getBytes(cs));
            if(adr2!=null)
                    ac.update(adr2.getBytes(cs));
            if(adr3!=null)
                ac.update(adr3.getBytes(cs));
            if(cp!=null)
                ac.update(cp.getBytes(cs));
            if(ville!=null)
                ac.update(ville.getBytes(cs));
            if(codePays!=null)
                ac.update(codePays.getBytes(cs));
            codeAdresse = ac.getFormattedValue();
        } catch(Exception ex) {
            ex.printStackTrace(System.err);
        }
        return getCodeAdresse();
    }
}
